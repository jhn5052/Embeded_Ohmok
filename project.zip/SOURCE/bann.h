/*
################################################################################
#                                                                               
#     ####   ###   #####  #     #  #####   <T.M>                                
#    #        #    #      #     #  #                                            
#     ####    #    ####    #   #   ####    Powered by Course-Ware Framework     
#         #   #    #        # #    #          (C) Copyrights, In4MaySun Inc     
#    #####   ###   #####     #     #####                                        
#                                                         www.in4maysun.com     
#    													   by Seo Kwang-Won
################################################################################
*/
//2014.5.21 1218

#ifndef __BANN_H__
#define __BANN_H__

void banner(void);
void draw_banner(void);

#endif
